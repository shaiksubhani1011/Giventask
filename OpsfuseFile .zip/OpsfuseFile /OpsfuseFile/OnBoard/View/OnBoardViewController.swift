//
//  OnBoardViewController.swift
//  CrewLead
//
//  Created by Shaik Subhani on 30/08/21.

//

import UIKit

class OnBoardViewController: UIViewController {
    
    @IBOutlet weak var collectionViewOnBoard:UICollectionView!
    @IBOutlet weak var pageController:UIPageControl!
    @IBOutlet weak var buttonSkip:UIButton!
    @IBOutlet weak var buttonNext:UIButton!
    @IBOutlet weak var gettingStaredButton: UIButton!
    
    var viewModel = OnBoardViewModel()
    
    //MARK: - Life cycle
    override func viewDidLoad() {
        super.viewDidLoad()
        buttonNext.isHidden = true
        self.viewModel.registerOnBoardTableNib(pageControl: self.pageController, table: self.collectionViewOnBoard) {
            self.collectionViewOnBoard.reloadData()
        }
        self.viewModel.closureSkip = { [unowned self] index in
            self.viewModel.screenIndex = index
            if index == 2{
                self.buttonSkip.isHidden = true
                self.buttonNext.isHidden = false
                self.gettingStaredButton.isHidden = true
                self.buttonNext.setTitle("Get started", for: .normal)
            }else{
                self.buttonSkip.isHidden = false
                self.buttonNext.isHidden = true
                self.gettingStaredButton.isHidden = false
            }
        }
    }
    
    //MARK: - Button Action
    
    //Skip button action
    @IBAction func skipButtonAction(_ sender:UIButton){
        navigateLogin()
    }
    //Invitation button action
    @IBAction func startButtonAction(_ sender:UIButton){
        if self.viewModel.screenIndex != 2{
            self.viewModel.screenIndex = self.viewModel.screenIndex == 0 ? 1 : 2
            self.viewModel.scrollToCollectionViewIdx()
        }else{
            navigateLogin()
        }
    }
    @IBAction func nextButtonAction(_ sender:UIButton){
        if self.viewModel.screenIndex != 2{
            self.viewModel.screenIndex = self.viewModel.screenIndex == 0 ? 1 : 2
            self.viewModel.scrollToCollectionViewIdx()
        }
    }
    
    //Navigate login controller
    private func navigateLogin() {
        if let vc = UIStoryboard(name: "OnBoard", bundle: nil).instantiateViewController(withIdentifier: "RegisterViewController") as? RegisterViewController {
            navigationController?.pushViewController(vc, animated: true)
        }
    }
}
