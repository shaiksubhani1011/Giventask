//
//  OnBoardCollectionViewCell.swift
//  CrewLead
//
//  Created by Shaik Subhani on 30/08/21.

//

import UIKit

class OnBoardCollectionViewCell: UICollectionViewCell {
    
    @IBOutlet weak var labelTitle:UILabel!
    @IBOutlet weak var labelDescription:UILabel!
    @IBOutlet weak var imageView:UIImageView!
    @IBOutlet weak var viewRounded:UIView!
    //OnBoard cell config
    func cellConfigOnBoard(data:OnBoardModel?){
        DispatchQueue.main.async {
            self.labelTitle.text = data?.title
            self.labelDescription.text = data?.description
            self.imageView.image = data?.image
        }
        
        
    }
}
