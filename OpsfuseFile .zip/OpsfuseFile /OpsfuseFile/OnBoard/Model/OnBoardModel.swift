//
//  OnBoardModel.swift
//  OpsfuseFile
//
//  Created by Shaik Subhani on 30/08/21.
//

import Foundation
import UIKit
struct OnBoardModel {
    var title:String?
    var description:String?
    var image:UIImage?
}

