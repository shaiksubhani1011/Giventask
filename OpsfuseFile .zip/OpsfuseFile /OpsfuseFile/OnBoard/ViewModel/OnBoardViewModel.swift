//
//  OnBoardViewModel.swift
//  CrewLead
//
//  Created by Shaik Subhani on 30/08/21.

//

import UIKit
class OnBoardViewModel:NSObject{
    
    var collectionView:UICollectionView!
    var pageControl = UIPageControl()
    var onBoardModelArray = [OnBoardModel]()
    var closureSkip: ((_ index:Int)->())?
    var screenIndex = 0
    
    let titleArray = ["Lets start Chating","Chat anywhere,anytime","Perfect chat solution"]
    let descriptionArray = ["passing of any infoemation on any screen, any device instantly is made simple at its sublime.","A lag free video chat connection between your users is easy an much everywhere an any device","passing of any information an any screen, any device instanly is made simple at its sublime."]
    
    //MARK: - Register tableview cells
    func registerOnBoardTableNib(pageControl:UIPageControl,table: UICollectionView, completion: @escaping() -> ()) {
        self.collectionView = table
        self.pageControl = pageControl
        pageControl.transform = CGAffineTransform(scaleX: 1.5, y: 1.5)
        let imageArray = [#imageLiteral(resourceName: "OnBoard-2"),#imageLiteral(resourceName: "OnBoard-3"),#imageLiteral(resourceName: "OnBoard-2")]
        for item in titleArray.enumerated(){
            onBoardModelArray.append(OnBoardModel.init(title: titleArray[item.offset], description: descriptionArray[item.offset], image:imageArray[item.offset]))
        }
        self.pageControl.currentPage = 0
        self.pageControl.numberOfPages = self.onBoardModelArray.count
        table.register(UINib(nibName: "OnBoardCollectionViewCell", bundle: nil), forCellWithReuseIdentifier: "OnBoardCollectionViewCell")
        table.dataSource = self
        table.delegate = self
        completion()
    }
    func scrollToCollectionViewIdx(){
      
        self.collectionView.scrollToItem(at: IndexPath.init(item: self.screenIndex, section: 0), at: .right, animated: true)
        self.pageControl.currentPage = self.screenIndex
        if let action = self.closureSkip{
            action(self.screenIndex)
        }
    }
}
//MARK: - Collectionview datasource & delegate
extension OnBoardViewModel:UICollectionViewDelegate,UICollectionViewDataSource,UICollectionViewDelegateFlowLayout{
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return onBoardModelArray.count
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        guard let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "OnBoardCollectionViewCell", for: indexPath) as?
            OnBoardCollectionViewCell else {return UICollectionViewCell()}
        cell.cellConfigOnBoard(data: self.onBoardModelArray[indexPath.row])
        return cell
    }
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize {
        return CGSize.init(width: collectionView.frame.size.width, height: collectionView.frame.size.height)
    }
    func scrollViewDidEndDecelerating(_ scrollView: UIScrollView) {
        var visibleRect = CGRect()
        
        visibleRect.origin = self.collectionView.contentOffset
        visibleRect.size = self.collectionView.bounds.size
        let visiblePoint = CGPoint(x: visibleRect.midX, y: visibleRect.midY)
        
        guard let indexPath = self.collectionView.indexPathForItem(at: visiblePoint) else { return }
        print(indexPath)
        self.pageControl.currentPage = indexPath.row
        if let action = self.closureSkip{
            action(indexPath.row)
        }
    }
    
}

