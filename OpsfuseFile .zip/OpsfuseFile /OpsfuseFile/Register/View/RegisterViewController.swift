//
//  RegisterViewController.swift
//  OpsfuseFile
//
//  Created by Shaik Subhani on 30/08/21.
//

import UIKit

class RegisterViewController: UIViewController {
    @IBOutlet weak var nameTextField: UITextField!
    @IBOutlet weak var dateOfBirthTextfield: UITextField!
    @IBOutlet weak var profileImageView: UIImageView!
    @IBOutlet weak var maleRadioView: UIView!
    @IBOutlet weak var femaleRadioView: UIView!
    @IBOutlet weak var submitButtom: UIButton!
    @IBOutlet weak var maleRadioButton: UIImageView!
    @IBOutlet weak var femaleRadioButton: UIImageView!
    var imagePicker = UIImagePickerController()
    @IBOutlet weak var maleRadioButtonCheck: UIButton!
    @IBOutlet weak var femaleRadioButtonCheck: UIButton!
    override func viewDidLoad() {
        super.viewDidLoad()
        dateOfBirthTextfield.addInputViewDatePicker(target: self, selector: #selector(doneButtonPressed))
        
        profileImageView.layer.cornerRadius = 10
        profileImageView.layer.borderWidth = 5
        profileImageView.layer.borderColor = UIColor.lightGray.cgColor
        profileImageView.layer.masksToBounds = false
        profileImageView.clipsToBounds = true
        
        maleRadioView.layer.cornerRadius = 5
        maleRadioView.layer.borderWidth = 1
        maleRadioView.layer.borderColor = UIColor.black.cgColor
        
        femaleRadioView.layer.cornerRadius = 5
        femaleRadioView.layer.borderWidth = 1
        femaleRadioView.layer.borderColor = UIColor.black.cgColor
        
        submitButtom.layer.cornerRadius = 5
        submitButtom.layer.borderWidth = 1
        submitButtom.layer.borderColor = UIColor.white.cgColor
    }
    
    @objc func doneButtonPressed() {
        if let  datePicker = self.dateOfBirthTextfield.inputView as? UIDatePicker {
            let dateFormatter = DateFormatter()
            dateFormatter.dateStyle = .medium
            self.dateOfBirthTextfield.text = dateFormatter.string(from: datePicker.date)
        }
        self.dateOfBirthTextfield.resignFirstResponder()
     }
    
    @IBAction func closeButtonTAp(_ sender: Any) {
        self.navigationController?.popViewController(animated: true)
    }
    
    @IBAction func chooseImageButton(_ sender: Any) {
        self.profileImageChangeBtn()
    }
    
    @IBAction func maleRadioButtonAction(_ sender: Any) {
        if maleRadioButtonCheck.isSelected {
            self.maleRadioButton.image = UIImage(named: "radioOn")
            
                } else {
                    self.maleRadioButton.image = UIImage(named: "radioOff")
                }
        maleRadioButtonCheck.isSelected = !maleRadioButtonCheck.isSelected
    }
    
    @IBAction func femaleRadioButtonAction(_ sender: Any) {
        if femaleRadioButtonCheck.isSelected == true {
            femaleRadioButton.image = UIImage(named: "radioOn")
                } else {
                    femaleRadioButton.image = UIImage(named: "radioOff")
                }
        femaleRadioButtonCheck.isSelected = !femaleRadioButtonCheck.isSelected
    }
    
    @IBAction func submitButtonAction(_ sender: Any) {
        if let vc = UIStoryboard(name: "OnBoard", bundle: nil).instantiateViewController(withIdentifier: "HotelBookingViewController") as? HotelBookingViewController {
            navigationController?.pushViewController(vc, animated: true)
        }
    }
}
extension RegisterViewController: UIImagePickerControllerDelegate, UINavigationControllerDelegate {
    func profileImageChangeBtn() {
        imagePicker.delegate = self
        imagePicker.allowsEditing = true
        let alert = UIAlertController(title: "Choose Image", message: nil, preferredStyle: .actionSheet)
        alert.addAction(UIAlertAction(title: "Camera", style: .default, handler: { _ in
            self.openCamera()
        }))
        
        alert.addAction(UIAlertAction(title: "Gallery", style: .default, handler: { _ in
            self.openGallary()
        }))
        
        alert.addAction(UIAlertAction.init(title: "Cancel", style: .cancel, handler: nil))

        self.present(alert, animated: true, completion: nil)
    }
    func openCamera(){
        if(UIImagePickerController .isSourceTypeAvailable(UIImagePickerController.SourceType.camera)){
            imagePicker.sourceType = UIImagePickerController.SourceType.camera
            imagePicker.allowsEditing = true
            self.present(imagePicker, animated: true, completion: nil)
        }else{
            let alert  = UIAlertController(title: "Warning", message: "You don't have camera", preferredStyle: .alert)
            alert.addAction(UIAlertAction(title: "OK", style: .default, handler: nil))
            self.present(alert, animated: true, completion: nil)
        }
    }
    
    func openGallary(){
        imagePicker.sourceType = UIImagePickerController.SourceType.photoLibrary
        imagePicker.allowsEditing = true
        self.present(imagePicker, animated: true, completion: nil)
    }
    func imagePickerController(_ picker: UIImagePickerController, didFinishPickingMediaWithInfo info: [UIImagePickerController.InfoKey : Any]) {
        let selectedImage = info[UIImagePickerController.InfoKey.editedImage]as? UIImage
        self.profileImageView.image = selectedImage
        self.dismiss(animated: true, completion: nil)
    }
    
}
extension UITextField {

   func addInputViewDatePicker(target: Any, selector: Selector) {

    let screenWidth = UIScreen.main.bounds.width

    //Add DatePicker as inputView
    let datePicker = UIDatePicker(frame: CGRect(x: 0, y: 0, width: screenWidth, height: 216))
    datePicker.datePickerMode = .date
    self.inputView = datePicker

    //Add Tool Bar as input AccessoryView
    let toolBar = UIToolbar(frame: CGRect(x: 0, y: 0, width: screenWidth, height: 44))
    let flexibleSpace = UIBarButtonItem(barButtonSystemItem: .flexibleSpace, target: nil, action: nil)
    let cancelBarButton = UIBarButtonItem(title: "Cancel", style: .plain, target: self, action: #selector(cancelPressed))
    let doneBarButton = UIBarButtonItem(title: "Done", style: .plain, target: target, action: selector)
    toolBar.setItems([cancelBarButton, flexibleSpace, doneBarButton], animated: false)

    self.inputAccessoryView = toolBar
 }

   @objc func cancelPressed() {
     self.resignFirstResponder()
   }
}

