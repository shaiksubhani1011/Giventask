//
//  HotelBookingViewModel.swift
//  OpsfuseFile
//
//  Created by Shaik Subhani on 30/08/21.
//

import UIKit

class HotelBookingViewModel: NSObject {
    func registerProductDetailsTableNib(table: UITableView, completion: @escaping(_ status: Bool) -> ()) {
        table.register(UINib(nibName: "BookingTableViewCell", bundle: nil), forCellReuseIdentifier: "BookingTableViewCell")
        table.register(UINib(nibName: "HotelsTableViewCell", bundle: nil), forCellReuseIdentifier: "HotelsTableViewCell")
        table.register(UINib(nibName: "BookingTableViewCell", bundle: nil), forCellReuseIdentifier: "BookingTableViewCell")
       
         table.register(UINib(nibName: "horizentalTableViewCell", bundle: nil), forCellReuseIdentifier: "horizentalTableViewCell")
       
        
        //                table.register(UINib(nibName: "ProductDeatilsTableViewCell", bundle: nil), forCellReuseIdentifier: "ProductDeatilsTableViewCell")
        table.dataSource = self
        table.delegate = self
        completion(true)
    }
    
}
extension HotelBookingViewModel: UITableViewDelegate, UITableViewDataSource {
    func numberOfSections(in tableView: UITableView) -> Int {
        return 1
    }
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return 4
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        switch indexPath.row{
        case 0:
            guard let cell = tableView.dequeueReusableCell(withIdentifier: "BookingTableViewCell") as? BookingTableViewCell else {
                return UITableViewCell()
            }
            
            cell.selectionStyle = .none
            return cell
        case 1:
            guard let cell = tableView.dequeueReusableCell(withIdentifier: "HotelsTableViewCell") as? HotelsTableViewCell else {
                return UITableViewCell()
            }
            
            cell.selectionStyle = .none
            return cell
            
        case 2:
            guard let cell = tableView.dequeueReusableCell(withIdentifier: "BookingTableViewCell") as? BookingTableViewCell else {
                return UITableViewCell()
            }
            
            cell.selectionStyle = .none
            return cell
                
        default:
            guard let cell = tableView.dequeueReusableCell(withIdentifier: "horizentalTableViewCell") as? horizentalTableViewCell else {
                return UITableViewCell()
            }
            
            cell.selectionStyle = .none
            return cell
            
        }
        
        
        
    }
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        switch indexPath.row{
        case 0:
            return UITableView.automaticDimension
        case 1:
            return 200
        case 2:
            return 50
        default:
            return 300
        }
        
    }
    func tableView(_ tableView: UITableView, estimatedHeightForRowAt indexPath: IndexPath) -> CGFloat {
        return UITableView.automaticDimension
    }
}
