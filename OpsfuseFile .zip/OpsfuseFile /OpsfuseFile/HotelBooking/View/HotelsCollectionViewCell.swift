//
//  HotelsCollectionViewCell.swift
//  OpsfuseFile
//
//  Created by Shaik Subhani on 30/08/21.
//

import UIKit

class HotelsCollectionViewCell: UICollectionViewCell {
    @IBOutlet weak var hotelImageView: UIImageView!
    @IBOutlet weak var hotelDetailsView: UIView!
    @IBOutlet weak var cosrLabel: UILabel!
    @IBOutlet weak var location: UILabel!
    @IBOutlet weak var hotelName: UILabel!
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

}
