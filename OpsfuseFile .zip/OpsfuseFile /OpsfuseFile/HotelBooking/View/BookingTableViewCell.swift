//
//  BookingTableViewCell.swift
//  OpsfuseFile
//
//  Created by Shaik Subhani on 30/08/21.
//

import UIKit

class BookingTableViewCell: UITableViewCell {
    @IBOutlet weak var HeaderCollectionView: UICollectionView!
    var titleArr = ["Recommanded","Top Ratings","Popular"]
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
        HeaderCollectionView.delegate = self
        HeaderCollectionView.dataSource = self
        HeaderCollectionView.register(UINib.init(nibName: "HeaderCollectionViewCell", bundle: nil), forCellWithReuseIdentifier: "HeaderCollectionViewCell")
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }
    
}
extension BookingTableViewCell: UICollectionViewDelegate, UICollectionViewDataSource, UICollectionViewDelegateFlowLayout {
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return titleArr.count
    }
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, insetForSectionAt section: Int) -> UIEdgeInsets {
        return UIEdgeInsets(top: 5, left: 5, bottom: 0, right: 5)
    }
    func collectionView(_ collectionView: UICollectionView,
                        layout collectionViewLayout: UICollectionViewLayout,
                        sizeForItemAt indexPath: IndexPath) -> CGSize {
      CGSize(width: UIScreen.main.bounds.width/3, height: collectionView.frame.size.height)
    }
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "HeaderCollectionViewCell", for: indexPath) as! HeaderCollectionViewCell
        cell.titleLabel.text = titleArr[indexPath.row]
        cell.titleView.layer.cornerRadius = 10
        cell.titleLabel.textColor = .systemBlue
        
        return cell
    }
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, minimumInteritemSpacingForSectionAt section: Int) -> CGFloat {
           return 20
       }
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, minimumLineSpacingForSectionAt section: Int) -> CGFloat {
           return 20
       }

    
    
}
