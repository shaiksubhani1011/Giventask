//
//  HotelBookingViewController.swift
//  OpsfuseFile
//
//  Created by Shaik Subhani on 30/08/21.
//

import UIKit

class HotelBookingViewController: UIViewController {
    @IBOutlet weak var nameLabel: UILabel!
    @IBOutlet weak var notificationButton: UIButton!
    @IBOutlet weak var searchBar: UISearchBar!
    @IBOutlet weak var filterButton: UIButton!
    @IBOutlet weak var tableView: UITableView!
    
    let viewModel = HotelBookingViewModel()
    override func viewDidLoad() {
        super.viewDidLoad()
        filterButton.layer.cornerRadius = 6
        searchBar.backgroundColor = .clear
        viewModel.registerProductDetailsTableNib(table: tableView) { status in
            self.tableView.reloadData()
        }
       
    }

}
