//
//  horizentalCollectionViewCell.swift
//  OpsfuseFile
//
//  Created by Shaik Subhani on 30/08/21.
//

import UIKit

class horizentalCollectionViewCell: UICollectionViewCell {
    @IBOutlet weak var imageView: UIImageView!
    @IBOutlet weak var DetailsView: UIView!
    @IBOutlet weak var hotelNameLB: UIStackView!
    @IBOutlet weak var hotalPrice: UILabel!
    @IBOutlet weak var ratingView: UIImageView!
    @IBOutlet weak var reviewOfHotelLB: UILabel!
    @IBOutlet weak var locationLB: UILabel!
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }
    
}
